/**
 A class to convert an url to canonical (normalized) form.
 */
public class URLCanonicalizer {

    public String getCanonicalURL(String url) {
        /********************************************************/
	/* GAP!							*/
	/* Here you need to implement whatever you think is 	*/
	/* necessary to canonicalize an URL			*/
	/********************************************************/
    }
}
